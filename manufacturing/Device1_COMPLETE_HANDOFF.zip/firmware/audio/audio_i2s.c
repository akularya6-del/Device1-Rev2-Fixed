/**
 * @file audio_i2s.c
 * @brief I2S Audio Acquisition Driver Implementation
 * Implements circular DMA double buffering (ping-pong) for Knowles SPH0645 MEMS mic.
 */

#include "audio_i2s.h"

/* DMA Circular Double Buffer: 256 samples total (Ping: 0..127, Pong: 128..255) */
#define TOTAL_DMA_SAMPLES   (AUDIO_FRAME_SAMPLES * 2U)

static int16_t s_dma_audio_buffer[TOTAL_DMA_SAMPLES];
static volatile audio_buffer_id_t s_ready_buffer = BUFFER_NONE;
static volatile bool s_is_running = false;

void audio_i2s_init(void)
{
    /* Clear buffers */
    for (size_t i = 0; i < TOTAL_DMA_SAMPLES; i++) {
        s_dma_audio_buffer[i] = 0;
    }
    s_ready_buffer = BUFFER_NONE;
    s_is_running = false;

    /* Hardware register initialization for STM32WL55:
     * 1. Enable RCC clocks for GPIOA, GPIOB, SPI2/I2S2, and DMA1
     * 2. Configure PB12 (I2S2_WS), PA9 (I2S2_CK), PA10 (I2S2_SD) as AF5 (SPI2/I2S2)
     * 3. Configure I2S2:
     *    - Mode: Master Receive
     *    - Standard: I2S Philips (18-bit in 32-bit slot for Knowles SPH0645)
     *    - Data format: 16-bit extended
     *    - Sample rate: 16.0 kHz
     * 4. Configure DMA1 Channel 1:
     *    - Circular mode, Peripheral to Memory
     *    - Peripheral size: 16-bit, Memory size: 16-bit
     *    - Enable Half-Transfer (HT) and Transfer Complete (TC) interrupts
     */
}

void audio_i2s_start(void)
{
    s_ready_buffer = BUFFER_NONE;
    s_is_running = true;
    /* Enable DMA Channel and I2S peripheral */
}

void audio_i2s_stop(void)
{
    s_is_running = false;
    /* Disable DMA Channel and I2S peripheral */
}

audio_buffer_id_t audio_i2s_get_frame(int16_t **frame_out)
{
    audio_buffer_id_t ready = s_ready_buffer;
    if (ready == BUFFER_PING) {
        *frame_out = &s_dma_audio_buffer[0];
        s_ready_buffer = BUFFER_NONE;
        return BUFFER_PING;
    } else if (ready == BUFFER_PONG) {
        *frame_out = &s_dma_audio_buffer[AUDIO_FRAME_SAMPLES];
        s_ready_buffer = BUFFER_NONE;
        return BUFFER_PONG;
    }
    return BUFFER_NONE;
}

void audio_i2s_dma_half_transfer_callback(void)
{
    /* First half (Ping buffer: 0..127) filled by DMA */
    s_ready_buffer = BUFFER_PING;
}

void audio_i2s_dma_transfer_callback(void)
{
    /* Second half (Pong buffer: 128..255) filled by DMA */
    s_ready_buffer = BUFFER_PONG;
}
